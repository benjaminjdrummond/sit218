package edu.deakin.sit218.coachwebapp.controller;


import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.deakin.sit218.coachwebapp.dao.QuestionDAO;
import edu.deakin.sit218.coachwebapp.dao.QuestionDAOImpl;
import edu.deakin.sit218.coachwebapp.entity.Question;

@Controller
@RequestMapping("/question")
public class CoachController {

	@RequestMapping("/processForm")
	public String knowledgearea(
			@Valid @ModelAttribute("question") Question question, 
			BindingResult validationErrors, Model model) {
		//Input validation
		if (validationErrors.hasErrors())
			return "question-form";

		//Retrieve Question object from database
		
		//Check whether the question doesn't exist
		QuestionDAO dao = new QuestionDAOImpl(); 
		if (!dao.existsQuestion(question)) 
			dao.insertQuestion(question); //If not, save it
		//This question object is identical to a row in the database
		question = dao.retrieveQuestion(question);

		//Logic when there is no error
				//Decide on the type of knowledge
				if (question.getQuestion().equals("What colour is a banana?")) {
					model.addAttribute("message", "Bobby why are you here");
				} 
				else if (question.getAnswer().equals("Yellow")) {
					model.addAttribute("message", "Hey, " + question.getAnswer()+ 
							" It's banana time");
				}
				else {
						model.addAttribute("message", question.getQuestion()+ 
								" has been added as a question"+
								System.lineSeparator()+ 
								" The area of knowledge is  "+question.getKnowledgeareas());	
				}
				
				
		//Sync Client object with database
		dao.updateQuestion(question);
				
				
		//Return the View 
		return "knowledgearea";
	}
	
}
